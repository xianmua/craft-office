/// Largest zip entry we inflate.
pub(super) const MAX_ENTRY: u64 = 256 << 20;

/// Deepest element nesting handled in content.xml.
pub(super) const MAX_XML_DEPTH: usize = 512;

/// Most sections an import makes (page-style changes and column sections); later ones are ignored.
pub(super) const MAX_SECTIONS: usize = 10_000;

/// Longest shown text a field keeps, in bytes.
pub(super) const MAX_FIELD_RESULT: usize = 64 << 10;

/// Most comments read; later ones are left out.
pub(super) const MAX_COMMENTS: usize = 100_000;

/// Most `text:changed-region`s read (hostile input).
pub(super) const MAX_REGIONS: usize = 10_000;

/// Most insertions open at once (`text:change-start` without its end yet).
pub(super) const MAX_OPEN_INSERTIONS: usize = 64;

/// Longest change author or date kept, in characters.
pub(super) const MAX_INFO_CHARS: usize = 256;
/// Most spaces the document's `text:s` elements add beyond the one each stands for (hostile input).
pub(super) const MAX_EXTRA_SPACES: usize = 4 << 20;
