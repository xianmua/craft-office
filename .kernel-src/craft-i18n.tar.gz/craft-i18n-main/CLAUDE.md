Read `AGENTS.md`.
